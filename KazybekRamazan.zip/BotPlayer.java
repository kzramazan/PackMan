public interface BotPlayer extends Player{
    void feed(Pood f);
    void traverse();
    void eat();
    void find();
}
