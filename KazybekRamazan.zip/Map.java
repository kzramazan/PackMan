import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import java.io.*;
import java.util.*;
public class Map extends Pane{
    private int unit = 50;
    private int size;
    private int[][] map;
    private Position start;
    Map(String dir) {
        try(Scanner in  = new Scanner(new File(dir))){
            size = in.nextInt();
            map = new int[size][size];
            for (int a = 0; map.length > a; a++){
                for (int j = 0; map.length > j; j++){
                    if (in.hasNext())
                        map[j][a] = in.nextInt();
                }
            }
        }
        catch (FileNotFoundException ex){}
        for (int i1 = 0;map.length > i1;i1++){
            for (int i2 = 0;map.length > i2;i2++){
                if (map[i1][i2] == 0) {
                    Rectangle rectangle = new Rectangle(i1 * getUnit(), i2 * getUnit(), getUnit(), getUnit());
                    rectangle.setFill(Color.TRANSPARENT);
                    rectangle.setStroke(Color.BLUE);
                    getChildren().addAll(rectangle);
                }
                else if (map[i1][i2] == 1){
                    Rectangle rectangle = new Rectangle(i1 * getUnit(), i2 * getUnit(), getUnit(), getUnit());
                    rectangle.setStroke(Color.BLACK);
                    rectangle.setFill(Color.BLACK);
                    getChildren().add(rectangle);
                }
                else if (map[i1][i2] == 2){
                    start = new Position(i1, i2);
                    Rectangle rectangle = new Rectangle(i1 * getUnit(), i2 * getUnit(), getUnit(), getUnit());
                    rectangle.setFill(Color.TRANSPARENT);
                    rectangle.setStroke(Color.BLUE);
                    getChildren().addAll(rectangle);
                }
            }
        }
    }
    public int getUnit(){
        return unit;
    }
    public int getSize(){
        return size;
    }
    public int[][] getMap(){
        return map;
    }
    public Position getStartPosition(){
        return start;
    }
}