import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.PrintWriter;

public class Game extends Application{
    Timeline timeline;
    private MyBotPlayer myBotPlayer;
    private Map map;
    private static String file;
    Scene scene1, scene2, scene3, scene4;//Menu, traverse
    int counter = 0;
    public static void main(String[] args){
        file = "map.txt";
        launch(args);
    }
    public void start(Stage stage) {
        Button TraverseButton = new Button("Traverse");
        Button EatButton = new Button("Eat");
        Button FindButton = new Button("Find");
        VBox vBox = new VBox(5);
        vBox.getChildren().addAll(TraverseButton, EatButton, FindButton);
        scene1 = new Scene(vBox);
        Button back = new Button("Back");
        //Traverse like a snake
        TraverseButton.setOnAction(e->{
            if (counter > 0)
                timeline.stop();
            counter++;
            map = new Map(file);
            myBotPlayer = new MyBotPlayer(map);
            Pood pood = new Pood(map, myBotPlayer);
            myBotPlayer.feed(pood);//Initializing food class
            myBotPlayer.setPositionForTraverse();
            map.getChildren().addAll(back);
            scene2 = new Scene(map);//Switching the scene
            stage.setScene(scene2);
            myBotPlayer.setPositionForTraverse();//Set Position to (0,0)
            //Event Handler for traverse method in MyBotPlayer class to traverse like a snake
            javafx.event.EventHandler<ActionEvent> eventHandler = new javafx.event.EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    myBotPlayer.traverse();
                    if (pood.getPosition().equals(myBotPlayer.getPosition())){//While ball eats food
                        timeline.stop();
                    }
                }
            };
            timeline = new Timeline(new KeyFrame(Duration.millis(100), eventHandler)); // Timeline for EventHandler
            timeline.setCycleCount(Timeline.INDEFINITE);//Timeline is Indefinite
            timeline.play();
        });
        EatButton.setOnAction(e->{//Without any walls eats all food elements by choosing the shortest path
            if (counter > 0)
                timeline.stop();
            counter++;
            map = new Map(file);
            myBotPlayer = new MyBotPlayer(map);
            Pood pood = new Pood(map, myBotPlayer);
            myBotPlayer.feed(pood);
            map.getChildren().addAll(back);
            scene2 = new Scene(map);//Switching the scene
            stage.setScene(scene2);
            javafx.event.EventHandler<ActionEvent> eventHandler = new javafx.event.EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    try {
                        myBotPlayer.eat();
                    }catch (Exception ex){timeline.stop();}//There is an exception if there's no food to eat
                }
            };
            timeline = new Timeline(new KeyFrame(Duration.millis(100), eventHandler)); // Timeline for EventHandler
            timeline.setCycleCount(Timeline.INDEFINITE);//Timeline is Indefinite
            timeline.play();
        });
        FindButton.setOnAction(e->{
            if (counter > 0)
                timeline.stop();
            counter++;
            map = new Map("map1.txt");
            myBotPlayer = new MyBotPlayer(map);
            Pood pood = new Pood(map, myBotPlayer);
            myBotPlayer.feed(pood);
            map.getChildren().addAll(back);
            scene2 = new Scene(map);//Switching the scene
            stage.setScene(scene2);
            javafx.event.EventHandler<ActionEvent> eventHandler = new javafx.event.EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    try {
                        if (!pood.getPosition().equals(myBotPlayer.getPosition()))
                            myBotPlayer.find();
                    }catch (Exception ex){timeline.stop();}//There is an exception if there's no food to eat
                }
            };
            timeline = new Timeline(new KeyFrame(Duration.millis(100), eventHandler)); // Timeline for EventHandler
            timeline.setCycleCount(Timeline.INDEFINITE);//Timeline is Indefinite
            timeline.play();

        });

        back.setOnAction(e->{//Button back to go back to menu
            stage.setScene(scene1);
        });
        stage.setTitle("PackManBotPlayer");
        stage.setScene(scene1);
        stage.show();
    }
}
