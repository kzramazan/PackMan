import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MyBotPlayer implements BotPlayer{
    private Circle ball;
    private Map map;
    private Position position;
    int[][] arr;
    private int left = 7, right = 0;
    private Pood f;
    MyBotPlayer(Map map){
        this.map = map;
        position = new Position(map.getStartPosition().getX(), map.getStartPosition().getY());
        ball = new Circle(position.getX()*map.getUnit() + map.getUnit()/2, position.getY()*map.getUnit() + map.getUnit()/2, map.getUnit()/2);
        ball.setFill(Color.RED);
        arr = map.getMap();
        map.getChildren().addAll(ball);
    }

    public void feed(Pood f){
        this.f = f;
    }
    public void traverse(){
        ball.setCenterX(position.getX()*map.getUnit() + map.getUnit()/2);
        ball.setCenterY(position.getY()*map.getUnit() + map.getUnit()/2);
        if (!(f.getPosition().equals(getPosition()))){//Check if food's position and ball's position are not equal
            if (right < 7) {
                right++;
                moveRight();
            } else if (right == 7) {
                moveDown();
                right = 8;
            } else if (left > 0) {
                left--;
                moveLeft();
            } else {
                right = 0;
                left = 7;
                moveDown();
            }
        }
    }
    public void setPositionForTraverse(){
        //That's due to start at position (0,0) to traverse method
        position.setY(0);
        position.setX(0);
    }
    public void eat(){
        if (!(f.getPosition().equals(getPosition()))){
            if (f.getPosition().getX() > getPosition().getX()){
                moveRight();
            }
            else if (f.getPosition().getX() < getPosition().getX()){
                moveLeft();
            }
            else if (f.getPosition().getY() > getPosition().getY()){
                moveDown();
            }
            else if (f.getPosition().getY() < getPosition().getY()){
                moveUp();
            }
        }
    }
    public void find(){
        int target;//food rectangle's number in array with 64 values in it
        int[][]  posDir= new int[map.getSize() * map.getSize()][map.getSize()*map.getSize()];//Array created to store possible directions where food can go
        boolean[] was = new boolean[map.getSize()*map.getSize()];//was/were or not
        int[] parent = new int[map.getSize()*map.getSize()];//parent
        target = f.getPosition().getX()*arr.length+f.getPosition().getY();
        LinkedList<Integer> q = new LinkedList<>();
        q.add(target);
        for(int i = 0; i < arr.length; i++) {
            for(int j = 0; j < arr.length; j++) {
                //Fill with 1 possible directions where food can go
                if(i > 0 && arr[j][i-1] != 1 ) {
                    posDir[arr.length*j+i][(arr.length*j+i-1)] = 1;
                }
                if(i < arr.length-1 && arr[j][i+1] != 1 ) {
                    posDir[arr.length*j+i][(arr.length*j+i+1)] = 1;
                }
                if(j > 0 && arr[j-1][i] != 1 ) {
                    posDir[arr.length*j+i][(arr.length*(j-1)+i)] = 1;
                }
                if(j < arr.length-1 && arr[j+1][i] != 1 ) {
                    posDir[arr.length*j+i][(arr.length*(j+1)+i)] = 1;
                }
            }
        }
        //BFS
        while (q.size() > 0) {
            int beginning = q.poll();
            was[beginning] = true;
            for(int i = 0; i < posDir[beginning].length; i++) {
                if(posDir[beginning][i] == 1) {//If there's a direction from V to I
                    if (!was[i]) {//If we weren't there
                        parent[i] = beginning;
                        q.addLast(i);
                    }
                }
            }
        }

        if (position.getX() * map.getSize() + position.getY() != target) {
            int pos = position.getX() * map.getSize() + position.getY();
            if (parent[pos] == position.getX() * map.getSize() + position.getY() + 1) {
                moveDown();
            }
            if (parent[pos] == position.getX() * map.getSize() + position.getY() - 1) {
                moveUp();
            }
            if (parent[pos] == (position.getX() + 1) * map.getSize() + position.getY()) {
                moveRight();
            }
            if (parent[pos] == (position.getX() - 1) * map.getSize() + position.getY()) {
                moveLeft();
            }
        }
    }


    public void moveRight(){
            position.setX(position.getX() + 1);//move the position
            ball.setCenterX(ball.getCenterX() + 50);//move the ball

    }

    public void moveLeft(){
            position.setX(position.getX() - 1);
            ball.setCenterX(ball.getCenterX() - 50);
    }


    public void moveUp(){
            position.setY(position.getY() - 1);
            ball.setCenterY(ball.getCenterY() - 50);
    }

    public void moveDown(){
            position.setY(position.getY() + 1);
            ball.setCenterY(ball.getCenterY() + 50);
    }

    public Position getPosition(){
        return position;
    }
}
